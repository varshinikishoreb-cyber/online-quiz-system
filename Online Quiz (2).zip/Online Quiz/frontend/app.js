const apiUrl = "/api/questions";
const authBase = "/api/auth";
const introPage = document.getElementById("intro-page");
const forgotPage = document.getElementById("forgot-page");
const resetPage = document.getElementById("reset-page");
const quizPage = document.getElementById("quiz-page");
const resultPage = document.getElementById("result-page");
const selectionPage = document.getElementById("selection-page");
const mathsBtn = document.getElementById("mathsBtn");
const webBtn = document.getElementById("webBtn");
const selectionLoading = document.getElementById("selectionLoading");
const selectionMessage = document.getElementById("selectionMessage");
const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");
const authSubmitBtn = document.getElementById("authSubmitBtn");
const authEmail = document.getElementById("authEmail");
const authPassword = document.getElementById("authPassword");
const authName = document.getElementById("authName");
const authMessage = document.getElementById("authMessage");
const registerExtra = document.getElementById("registerExtra");
const forgotPageBtn = document.getElementById("forgotPageBtn");
const forgotEmail = document.getElementById("forgotEmail");
const forgotSubmitBtn = document.getElementById("forgotSubmitBtn");
const backToLoginBtn = document.getElementById("backToLoginBtn");
const backToLoginBtn2 = document.getElementById("backToLoginBtn2");
const forgotMessage = document.getElementById("forgotMessage");
const resetTokenInput = document.getElementById("resetTokenInput");
const resetPasswordInput = document.getElementById("resetPassword");
const resetConfirmPasswordInput = document.getElementById("resetConfirmPassword");
const resetSubmitBtn = document.getElementById("resetSubmitBtn");
const resetMessage = document.getElementById("resetMessage");
const passwordToggleButtons = document.querySelectorAll(".password-toggle");
const logoutBtn = document.getElementById("logoutBtn");
const playerLabel = document.getElementById("playerLabel");
const questionText = document.getElementById("questionText");
const optionsContainer = document.getElementById("optionsContainer");
const timerLabel = document.getElementById("timerLabel");
const progressFill = document.getElementById("progressFill");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const submitBtn = document.getElementById("submitBtn");
const restartBtn = document.getElementById("restartBtn");
const scoreText = document.getElementById("scoreText");
const percentageText = document.getElementById("percentageText");
const correctText = document.getElementById("correctText");
const wrongText = document.getElementById("wrongText");
const feedbackText = document.getElementById("feedbackText");
const reviewContainer = document.getElementById("reviewContainer");
const dashboardPage = document.getElementById("dashboard-page");
const historyPage = document.getElementById("history-page");
const leaderboardPage = document.getElementById("leaderboard-page");
const navBar = document.getElementById("navBar");
const navLinks = document.querySelectorAll(".nav-link");
const logoutNavBtn = document.getElementById("logoutNavBtn");
const themeToggleBtn = document.getElementById("themeToggle");
const navUsername = document.getElementById("navUsername");
const profileName = document.getElementById("profileName");
const profileEmail = document.getElementById("profileEmail");
const editProfileBtn = document.getElementById("editProfileBtn");
const profileEditForm = document.getElementById("profileEditForm");
const profileNameInput = document.getElementById("profileNameInput");
const saveProfileBtn = document.getElementById("saveProfileBtn");
const cancelProfileBtn = document.getElementById("cancelProfileBtn");
const profileMessage = document.getElementById("profileMessage");
const historyTopicFilter = document.getElementById("historyTopicFilter");
const resultsTableBody = document.querySelector("#resultsTable tbody");
const leaderboardList = document.getElementById("leaderboardList");
const dashboardAttempts = document.getElementById("dashboardAttempts");
const dashboardAverage = document.getElementById("dashboardAverage");
const dashboardBest = document.getElementById("dashboardBest");
const dashboardRank = document.getElementById("dashboardRank");

let selectedTopic = null;
let questions = [];
let currentIndex = 0;
let answers = [];
let timer = null;
let remainingSeconds = 0;
let authMode = "login";
let cachedResults = [];

const playSound = (isCorrect) => {
  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  const oscillator = audioCtx.createOscillator();
  const gainNode = audioCtx.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(audioCtx.destination);
  oscillator.type = isCorrect ? "triangle" : "sawtooth";
  oscillator.frequency.value = isCorrect ? 640 : 180;
  gainNode.gain.value = 0.08;

  oscillator.start();
  setTimeout(() => {
    oscillator.stop();
    audioCtx.close();
  }, 140);
};

const hideAllPages = () => {
  [introPage, forgotPage, resetPage, selectionPage, quizPage, resultPage, dashboardPage, historyPage, leaderboardPage].forEach((section) => section.classList.add("hidden"));
};

const showPage = (page) => {
  hideAllPages();
  navBar.classList.toggle("hidden", page === introPage || page === forgotPage || page === resetPage);
  page.classList.remove("hidden");
};

const showAuthMessage = (message, type = "error") => {
  authMessage.textContent = message;
  authMessage.className = `auth-message ${type}`;
};

const showForgotMessage = (message, type = "error") => {
  forgotMessage.textContent = message;
  forgotMessage.className = `auth-message ${type}`;
};

const showResetMessage = (message, type = "error") => {
  resetMessage.textContent = message;
  resetMessage.className = `auth-message ${type}`;
};

const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
};

const togglePasswordVisibility = (button) => {
  const input = document.getElementById(button.dataset.target);
  if (!input) return;

  const showing = input.type === "text";
  input.type = showing ? "password" : "text";
  button.textContent = showing ? "👁" : "🙈";
  button.setAttribute("aria-label", showing ? "Show password" : "Hide password");
};

passwordToggleButtons.forEach((button) => {
  button.addEventListener("click", () => togglePasswordVisibility(button));
});

const clearAuthInputs = () => {
  authEmail.value = "";
  authPassword.value = "";
  authName.value = "";
};

const setAuthMode = (mode) => {
  authMode = mode;
  loginTab.classList.toggle("active", mode === "login");
  registerTab.classList.toggle("active", mode === "register");
  authSubmitBtn.textContent = mode === "login" ? "Login" : "Register";
  registerExtra.classList.toggle("hidden", mode !== "register");
  showAuthMessage("", "");
  clearAuthInputs();
};

const setProfileDetails = () => {
  const storedName = localStorage.getItem("playerName") || "Guest";
  const storedEmail = localStorage.getItem("playerEmail") || "guest@example.com";
  profileName.textContent = storedName;
  profileEmail.textContent = storedEmail;
  navUsername.textContent = storedName;
  playerLabel.textContent = storedName;
};

const showProfileMessage = (message, type = "error") => {
  profileMessage.textContent = message;
  profileMessage.className = `auth-message ${type}`;
  profileMessage.classList.remove("hidden");
};

const hideProfileEdit = () => {
  profileEditForm.classList.add("hidden");
  profileMessage.classList.add("hidden");
};

const showProfileEdit = () => {
  profileNameInput.value = localStorage.getItem("playerName") || "";
  profileEditForm.classList.remove("hidden");
  profileNameInput.focus();
};

const updateProfileName = async () => {
  const newName = profileNameInput.value.trim();
  if (!newName) {
    showProfileMessage("Display name cannot be empty.", "error");
    return;
  }

  try {
    const response = await fetch(`${authBase}/profile`, {
      method: "PUT",
      headers: getAuthHeaders(),
      body: JSON.stringify({ name: newName }),
    });
    const data = await response.json();
    if (!response.ok) {
      showProfileMessage(data.message || "Unable to update profile.", "error");
      return;
    }

    localStorage.setItem("playerName", data.user.username || newName);
    localStorage.setItem("playerEmail", data.user.email);
    localStorage.setItem("token", data.token);
    setProfileDetails();
    showProfileMessage("Name updated successfully.", "success");
    setTimeout(hideProfileEdit, 900);
  } catch (error) {
    showProfileMessage("Unable to connect to the server.", "error");
    console.error(error);
  }
};

const getSelectedTopic = () => {
  return selectedTopic || localStorage.getItem("quizTopic") || "maths";
};

const updateProgress = () => {
  const progress = ((currentIndex + 1) / questions.length) * 100;
  progressFill.style.width = `${progress}%`;
};

const renderQuestion = () => {
  const question = questions[currentIndex];
  if (!question) return;

  questionText.textContent = `${currentIndex + 1}. ${question.question}`;
  optionsContainer.innerHTML = "";
  remainingSeconds = question.timer;
  timerLabel.textContent = remainingSeconds;

  question.options.forEach((option) => {
    const optionButton = document.createElement("button");
    optionButton.type = "button";
    optionButton.className = "option-item";
    optionButton.textContent = option;

    const selectedAnswer = answers.find((item) => item.id === question.id)?.answer;
    if (selectedAnswer === option) {
      optionButton.classList.add("selected");
    }

    optionButton.addEventListener("click", () => {
      saveAnswer(question.id, option);
      document.querySelectorAll(".option-item").forEach((btn) => btn.classList.remove("selected"));
      optionButton.classList.add("selected");
      playSound(option === question.correctAnswer);
    });

    optionsContainer.appendChild(optionButton);
  });

  const isLastQuestion = currentIndex === questions.length - 1;
  prevBtn.disabled = currentIndex === 0;
  nextBtn.disabled = false;
  nextBtn.textContent = isLastQuestion ? "Submit" : "Next";
  submitBtn.classList.toggle("hidden", !isLastQuestion);
  updateProgress();
};

const saveAnswer = (questionId, answer) => {
  const existing = answers.find((item) => item.id === questionId);
  if (existing) {
    existing.answer = answer;
  } else {
    answers.push({ id: questionId, answer });
  }
};

const updateTimer = () => {
  if (remainingSeconds <= 0) {
    clearInterval(timer);
    nextBtn.click();
    return;
  }

  remainingSeconds -= 1;
  timerLabel.textContent = remainingSeconds;
};

const startTimer = () => {
  clearInterval(timer);
  timer = setInterval(updateTimer, 1000);
};

const renderReview = (results) => {
  reviewContainer.innerHTML = "";

  results.forEach((item, index) => {
    const card = document.createElement("div");
    card.className = `review-card ${item.isCorrect ? "correct" : "wrong"}`;
    card.innerHTML = `
      <h4>Q${index + 1}: ${item.question}</h4>
      <p>Your answer: <strong>${item.userAnswer || "No answer"}</strong></p>
      <p>Correct answer: <strong>${item.correctAnswer}</strong></p>
    `;
    reviewContainer.appendChild(card);
  });
};

const saveResult = async (result) => {
  try {
    await fetch("/api/quiz/save-result", {
      method: "POST",
      headers: getAuthHeaders(),
      body: JSON.stringify({
        topic: getSelectedTopic(),
        score: result.score,
        totalQuestions: result.totalQuestions,
        percentage: result.percentage,
      }),
    });
    await refreshDashboardStats();
  } catch (error) {
    console.error("Could not save quiz result:", error);
  }
};

const refreshDashboardStats = async () => {
  try {
    const [resultsResponse, leaderboardResponse] = await Promise.all([
      fetch("/api/quiz/my-results", { headers: getAuthHeaders() }),
      fetch("/api/leaderboard", { headers: getAuthHeaders() }),
    ]);

    if (resultsResponse.status === 401 || leaderboardResponse.status === 401) {
      return;
    }

    const resultsData = await resultsResponse.json();
    const leaderboardData = await leaderboardResponse.json();
    const results = resultsData.results || [];
    const totalAttempts = results.length;
    const totalPercentage = results.reduce((sum, item) => sum + item.percentage, 0);
    const bestScore = results.reduce((best, item) => Math.max(best, item.score), 0);
    const averagePercent = totalAttempts ? Math.round(totalPercentage / totalAttempts) : 0;

    dashboardAttempts.textContent = totalAttempts;
    dashboardAverage.textContent = `${averagePercent}%`;
    dashboardBest.textContent = bestScore;
    dashboardRank.textContent = leaderboardData.currentUserRank || "N/A";
  } catch (error) {
    console.error("Unable to refresh dashboard stats:", error);
  }
};

const loadQuestions = async (topic) => {
  const selected = topic || getSelectedTopic();
  selectedTopic = selected;
  localStorage.setItem("quizTopic", selected);

  try {
    const response = await fetch(`${apiUrl}?topic=${selected}`, {
      headers: getAuthHeaders(),
    });

    if (response.status === 401) {
      logout();
      return null;
    }

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || "Unable to load questions.");
    }

    return data.questions || [];
  } catch (error) {
    console.error(error);
    return null;
  }
};

const startQuiz = async (topic) => {
  selectionLoading.classList.remove("hidden");
  selectionMessage.classList.add("hidden");
  mathsBtn.disabled = true;
  webBtn.disabled = true;

  const qs = await loadQuestions(topic);

  selectionLoading.classList.add("hidden");
  mathsBtn.disabled = false;
  webBtn.disabled = false;

  if (!qs) {
    selectionMessage.textContent = "Unable to load questions. Try again.";
    selectionMessage.classList.remove("hidden");
    return;
  }

  questions = qs;
  currentIndex = 0;
  answers = [];
  showPage(quizPage);
  renderQuestion();
  startTimer();
};

const submitQuiz = async () => {
  clearInterval(timer);
  const selectedTopic = getSelectedTopic();

  try {
    const response = await fetch("/api/submit", {
      method: "POST",
      headers: getAuthHeaders(),
      body: JSON.stringify({ answers, topic: selectedTopic }),
    });

    if (response.status === 401) {
      logout();
      return;
    }

    const result = await response.json();
    if (!response.ok) {
      feedbackText.textContent = result.message || "Submission failed.";
      return;
    }

    scoreText.textContent = `${result.score} / ${result.totalQuestions}`;
    percentageText.textContent = `${result.percentage}%`;
    correctText.textContent = result.correctAnswers;
    wrongText.textContent = result.wrongAnswers;
    renderReview(result.results || []);

    if (result.percentage >= 80) {
      feedbackText.textContent = "Cybernetic champion! Your reflexes are sharp and your logic is on point.";
    } else if (result.percentage >= 50) {
      feedbackText.textContent = "Solid performance. A little more logic tuning and you will be unbeatable.";
    } else {
      feedbackText.textContent = "Keep practicing—the future is waiting for your best run.";
    }

    await saveResult(result);
    showPage(resultPage);
  } catch (error) {
    feedbackText.textContent = "Submission failed. Try again in a moment.";
    console.error(error);
  }
};

const authenticate = async () => {
  const email = authEmail.value.trim();
  const password = authPassword.value.trim();
  const name = authName.value.trim();

  if (!email || !password) {
    showAuthMessage("Email and password are required.", "error");
    return;
  }

  const payload = { email, password };
  if (authMode === "register") {
    payload.name = name || email;
  }

  try {
    const response = await fetch(`${authBase}/${authMode}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await response.json();
    if (!response.ok) {
      showAuthMessage(data.message || "Authentication failed.", "error");
      return;
    }

    showAuthMessage(data.message || "Success! Redirecting...", "success");
    localStorage.setItem("token", data.token);
    localStorage.setItem("playerName", data.user.username || data.user.email);
    localStorage.setItem("playerEmail", data.user.email);
    localStorage.setItem("quizTopic", getSelectedTopic());
    playerLabel.textContent = data.user.username || data.user.email;
    navUsername.textContent = data.user.username || data.user.email;

    setTimeout(() => {
      loadDashboard();
    }, 450);
  } catch (error) {
    showAuthMessage("Unable to connect to the server.", "error");
    console.error(error);
  }
};

const sendForgotPassword = async () => {
  const email = forgotEmail.value.trim();
  if (!email) {
    showForgotMessage("Email is required.", "error");
    return;
  }

  try {
    const response = await fetch(`${authBase}/forgot-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    const data = await response.json();
    if (!response.ok) {
      showForgotMessage(data.message || "Unable to send reset link.", "error");
      return;
    }

    showForgotMessage("Reset link generated. Check the server console for the link.", "success");
  } catch (error) {
    showForgotMessage("Unable to connect to the server.", "error");
    console.error(error);
  }
};

const resetPassword = async () => {
  const token = resetTokenInput.value.trim();
  const password = resetPasswordInput.value.trim();
  const confirmPassword = resetConfirmPasswordInput.value.trim();

  if (!token || !password || !confirmPassword) {
    showResetMessage("All fields are required.", "error");
    return;
  }

  if (password !== confirmPassword) {
    showResetMessage("Passwords do not match.", "error");
    return;
  }

  try {
    const response = await fetch(`${authBase}/reset-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, password }),
    });

    const data = await response.json();
    if (!response.ok) {
      showResetMessage(data.message || "Unable to reset password.", "error");
      return;
    }

    showResetMessage("Password reset successful. Please login.", "success");
    setTimeout(() => {
      showPage(introPage);
      setAuthMode("login");
    }, 900);
  } catch (error) {
    showResetMessage("Unable to connect to the server.", "error");
    console.error(error);
  }
};

const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("playerName");
  localStorage.removeItem("quizTopic");
  navUsername.textContent = "Guest";
  setAuthMode("login");
  showPage(introPage);
};

const openForgotPage = () => {
  showForgotMessage("", "");
  forgotEmail.value = "";
  showPage(forgotPage);
};

const openResetPage = (token = "") => {
  showResetMessage("", "");
  resetTokenInput.value = token;
  resetPasswordInput.value = "";
  resetConfirmPasswordInput.value = "";
  showPage(resetPage);
};

const loadDashboard = async () => {
  try {
    const [resultsResponse, leaderboardResponse] = await Promise.all([
      fetch("/api/quiz/my-results", { headers: getAuthHeaders() }),
      fetch("/api/leaderboard", { headers: getAuthHeaders() }),
    ]);

    if (resultsResponse.status === 401 || leaderboardResponse.status === 401) {
      logout();
      return;
    }

    const resultsData = await resultsResponse.json();
    const leaderboardData = await leaderboardResponse.json();

    const results = resultsData.results || [];
    const totalAttempts = results.length;
    const totalPercentage = results.reduce((sum, item) => sum + item.percentage, 0);
    const bestScore = results.reduce((best, item) => Math.max(best, item.score), 0);
    const averagePercent = totalAttempts ? Math.round(totalPercentage / totalAttempts) : 0;

    dashboardAttempts.textContent = totalAttempts;
    dashboardAverage.textContent = `${averagePercent}%`;
    dashboardBest.textContent = bestScore;
    dashboardRank.textContent = leaderboardData.currentUserRank || "N/A";
    const storedName = localStorage.getItem("playerName") || "Guest";
    const storedEmail = localStorage.getItem("playerEmail") || "guest@example.com";
    navUsername.textContent = storedName;
    playerLabel.textContent = storedName;
    profileName.textContent = storedName;
    profileEmail.textContent = storedEmail;

    showPage(dashboardPage);
  } catch (error) {
    console.error("Unable to load dashboard:", error);
    showPage(dashboardPage);
  }
};

const renderHistory = (filter = "all") => {
  resultsTableBody.innerHTML = "";
  const visible = cachedResults.filter((item) => filter === "all" || item.topic === filter);

  if (!visible.length) {
    const row = document.createElement("tr");
    row.innerHTML = `<td colspan="4">No results match the selected filter.</td>`;
    resultsTableBody.appendChild(row);
    return;
  }

  visible.forEach((item) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${new Date(item.date).toLocaleString()}</td>
      <td>${item.topic}</td>
      <td>${item.score} / ${item.totalQuestions}</td>
      <td>${item.percentage}%</td>
    `;
    resultsTableBody.appendChild(row);
  });
};

const loadHistory = async () => {
  try {
    const response = await fetch("/api/quiz/my-results", { headers: getAuthHeaders() });
    if (response.status === 401) {
      logout();
      return;
    }

    const data = await response.json();
    cachedResults = data.results || [];
    renderHistory(historyTopicFilter.value);
    showPage(historyPage);
  } catch (error) {
    console.error("Unable to load history:", error);
    cachedResults = [];
    renderHistory(historyTopicFilter.value);
    showPage(historyPage);
  }
};

const loadLeaderboard = async () => {
  try {
    const response = await fetch("/api/leaderboard", { headers: getAuthHeaders() });
    if (response.status === 401) {
      logout();
      return;
    }

    const data = await response.json();
    leaderboardList.innerHTML = "";

    (data.leaderboard || []).forEach((entry) => {
      const card = document.createElement("div");
      card.className = "leaderboard-entry";
      card.innerHTML = `
        <span class="leaderboard-rank">#${entry.rank}</span>
        <div>
          <strong>${entry.username}</strong>
          <p>${entry.totalScore} pts · ${entry.averagePercentage}% avg</p>
        </div>
      `;
      leaderboardList.appendChild(card);
    });

    showPage(leaderboardPage);
  } catch (error) {
    console.error("Unable to load leaderboard:", error);
    showPage(leaderboardPage);
  }
};

const applyTheme = (theme) => {
  if (!themeToggleBtn) return;
  document.documentElement.dataset.theme = theme;
  themeToggleBtn.textContent = theme === "dark" ? "Light Mode" : "Dark Mode";
  localStorage.setItem("theme", theme);
};

const toggleTheme = () => {
  const nextTheme = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  applyTheme(nextTheme);
};

const initTheme = () => {
  const storedTheme = localStorage.getItem("theme");
  const preferredDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  applyTheme(storedTheme || (preferredDark ? "dark" : "light"));
};

const initFromUrl = () => {
  const path = window.location.pathname;
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get("token") || "";

  if (path.includes("/reset-password") && token) {
    openResetPage(token);
    return;
  }

  const tokenExists = localStorage.getItem("token");
  const storedName = localStorage.getItem("playerName");

  if (tokenExists) {
    navUsername.textContent = storedName || "Guest";
    playerLabel.textContent = storedName || "Guest";
    loadDashboard();
  } else {
    showPage(introPage);
    setAuthMode("login");
  }
};

loginTab.addEventListener("click", () => setAuthMode("login"));
registerTab.addEventListener("click", () => setAuthMode("register"));
authSubmitBtn.addEventListener("click", authenticate);
forgotPageBtn.addEventListener("click", openForgotPage);
forgotSubmitBtn.addEventListener("click", sendForgotPassword);
backToLoginBtn.addEventListener("click", () => {
  showPage(introPage);
  setAuthMode("login");
});
backToLoginBtn2.addEventListener("click", () => {
  showPage(introPage);
  setAuthMode("login");
});
resetSubmitBtn.addEventListener("click", resetPassword);
editProfileBtn.addEventListener("click", showProfileEdit);
saveProfileBtn.addEventListener("click", updateProfileName);
cancelProfileBtn.addEventListener("click", hideProfileEdit);
nextBtn.addEventListener("click", () => {
  if (currentIndex < questions.length - 1) {
    currentIndex += 1;
    renderQuestion();
    startTimer();
  } else {
    submitQuiz();
  }
});
prevBtn.addEventListener("click", () => {
  if (currentIndex > 0) {
    currentIndex -= 1;
    renderQuestion();
    startTimer();
  }
});
submitBtn.addEventListener("click", submitQuiz);
logoutBtn.addEventListener("click", logout);
logoutNavBtn.addEventListener("click", logout);
restartBtn.addEventListener("click", () => startQuiz(getSelectedTopic()));
mathsBtn.addEventListener("click", () => startQuiz("maths"));
webBtn.addEventListener("click", () => startQuiz("webdev"));
historyTopicFilter.addEventListener("change", () => renderHistory(historyTopicFilter.value));
navLinks.forEach((button) => {
  button.addEventListener("click", () => {
    const page = button.dataset.page;
    if (page === "dashboard") loadDashboard();
    if (page === "quiz") showPage(selectionPage);
    if (page === "history") loadHistory();
    if (page === "leaderboard") loadLeaderboard();
  });
});

themeToggleBtn?.addEventListener("click", toggleTheme);

window.addEventListener("load", () => {
  initTheme();
  initFromUrl();
});

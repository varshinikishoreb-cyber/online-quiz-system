# Online Quiz Website

A beginner-friendly full-stack quiz app with a cyberpunk UI.

## Project structure

- `/backend` - Node.js + Express API
- `/frontend` - HTML, CSS, JavaScript user interface

## Run locally

1. Open terminal in `c:\Users\adapa\OneDrive\Desktop\Online Quiz\backend`
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the backend server:
   ```bash
   npm start
   ```
4. Open your browser and navigate to:
   ```
   http://localhost:5000
   ```

## API endpoints

- `POST /api/auth/register` - register a new user and return a JWT token
- `POST /api/auth/login` - login with email and password and return a JWT token
- `POST /api/auth/forgot-password` - request a password reset link (console output)
- `POST /api/auth/reset-password` - submit a reset token and new password
- `GET /api/questions?topic=maths` - returns shuffled Maths questions for authenticated users
- `GET /api/questions?topic=webdev` - returns shuffled Web Development questions for authenticated users
- `POST /api/submit` - accepts answers and returns score for authenticated users

## Notes

- Users are stored in `/backend/data/users.json` with hashed passwords
- Questions are stored in `/backend/data/questions.js` by topic
- JWT tokens are verified for protected quiz routes
- Frontend saves the token in `localStorage` and includes it in request headers
- The password reset link is simulated and logged to the backend console

## Notes

- Questions are stored in `/backend/data/questions.json`
- Frontend is served statically by the Express server
- The app includes a timer, progress bar, result page, and restart flow

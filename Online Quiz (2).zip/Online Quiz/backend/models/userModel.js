const fs = require("fs");
const path = require("path");

const usersPath = path.join(__dirname, "..", "data", "users.json");

const loadUsers = () => {
  try {
    const content = fs.readFileSync(usersPath, "utf-8");
    return JSON.parse(content);
  } catch (error) {
    return [];
  }
};

const saveUsers = (users) => {
  fs.writeFileSync(usersPath, JSON.stringify(users, null, 2), "utf-8");
};

const findUserByEmail = (email) => {
  const users = loadUsers();
  return users.find((user) => user.email.toLowerCase() === email.toLowerCase());
};

const findUserById = (id) => {
  const users = loadUsers();
  return users.find((user) => user.id === id);
};

const createUser = (email, passwordHash, username = "") => {
  const users = loadUsers();
  const newUser = {
    id: users.length ? users[users.length - 1].id + 1 : 1,
    email,
    username,
    passwordHash,
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  saveUsers(users);
  return newUser;
};

const updatePassword = (id, passwordHash) => {
  const users = loadUsers();
  const userIndex = users.findIndex((user) => user.id === id);
  if (userIndex === -1) {
    return null;
  }

  users[userIndex].passwordHash = passwordHash;
  saveUsers(users);
  return users[userIndex];
};

const updateUsername = (id, username) => {
  const users = loadUsers();
  const userIndex = users.findIndex((user) => user.id === id);
  if (userIndex === -1) {
    return null;
  }

  users[userIndex].username = username;
  saveUsers(users);
  return users[userIndex];
};

module.exports = {
  loadUsers,
  saveUsers,
  findUserByEmail,
  findUserById,
  createUser,
  updatePassword,
  updateUsername,
};

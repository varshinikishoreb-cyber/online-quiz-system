const fs = require("fs");
const path = require("path");

const resultsPath = path.join(__dirname, "..", "data", "results.json");

const loadResults = () => {
  try {
    const content = fs.readFileSync(resultsPath, "utf-8");
    return JSON.parse(content);
  } catch (error) {
    return [];
  }
};

const saveResults = (results) => {
  fs.writeFileSync(resultsPath, JSON.stringify(results, null, 2), "utf-8");
};

const createResult = ({ userId, topic, score, totalQuestions, percentage }) => {
  const results = loadResults();
  const newResult = {
    id: results.length ? results[results.length - 1].id + 1 : 1,
    userId,
    topic,
    score,
    totalQuestions,
    percentage,
    date: new Date().toISOString(),
  };

  results.push(newResult);
  saveResults(results);
  return newResult;
};

const getResultsByUserId = (userId) => {
  const results = loadResults();
  return results.filter((result) => result.userId === userId);
};

const getAllResults = () => loadResults();

module.exports = {
  loadResults,
  saveResults,
  createResult,
  getResultsByUserId,
  getAllResults,
};

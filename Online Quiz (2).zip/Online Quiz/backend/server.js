const express = require("express");
const cors = require("cors");
const path = require("path");
const authRoute = require("./routes/auth");
const quizRoute = require("./routes/quiz");
const resultsRoute = require("./routes/results");
const leaderboardRoute = require("./routes/leaderboard");

const app = express();
const PORT = process.env.PORT || 5000;
const frontendPath = path.join(__dirname, "..", "frontend");

// Enable CORS so the frontend can fetch the quiz API
app.use(cors());

// Enable JSON parsing for POST requests
app.use(express.json());

// API routes
app.use("/api/auth", authRoute);
app.use("/api", quizRoute);
app.use("/api", resultsRoute);
app.use("/api", leaderboardRoute);

// Serve frontend static files
app.use(express.static(frontendPath));
app.get("*", (req, res) => {
  res.sendFile(path.join(frontendPath, "index.html"));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

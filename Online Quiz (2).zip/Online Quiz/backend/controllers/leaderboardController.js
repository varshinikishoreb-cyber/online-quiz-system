const { getAllResults } = require("../models/resultModel");
const { findUserById } = require("../models/userModel");

const getLeaderboard = (req, res) => {
  const allResults = getAllResults();

  const scoresByUser = allResults.reduce((acc, result) => {
    const userStats = acc[result.userId] || { userId: result.userId, totalScore: 0, totalPercentage: 0, attempts: 0 };
    userStats.totalScore += result.score;
    userStats.totalPercentage += result.percentage;
    userStats.attempts += 1;
    acc[result.userId] = userStats;
    return acc;
  }, {});

  const leaderboard = Object.values(scoresByUser)
    .map((item) => {
      const user = findUserById(item.userId);
      return {
        userId: item.userId,
        username: user ? user.username : "Unknown",
        totalScore: item.totalScore,
        averagePercentage: item.attempts ? Math.round(item.totalPercentage / item.attempts) : 0,
      };
    })
    .sort((a, b) => {
      if (b.totalScore !== a.totalScore) return b.totalScore - a.totalScore;
      return b.averagePercentage - a.averagePercentage;
    });

  const ranked = leaderboard.map((entry, index) => ({
    ...entry,
    rank: index + 1,
  }));

  const currentUserRank = ranked.find((entry) => entry.userId === req.user.userId)?.rank || null;
  const topTen = ranked.slice(0, 10);

  return res.json({ status: "success", leaderboard: topTen, currentUserRank });
};

module.exports = {
  getLeaderboard,
};

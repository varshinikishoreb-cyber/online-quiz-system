const { createResult, getResultsByUserId } = require("../models/resultModel");

const saveQuizResult = (req, res) => {
  const { topic, score, totalQuestions, percentage } = req.body;
  const userId = req.user.userId;

  if (!topic || score == null || totalQuestions == null || percentage == null) {
    return res.status(400).json({ status: "error", message: "All quiz result fields are required." });
  }

  const savedResult = createResult({
    userId,
    topic,
    score,
    totalQuestions,
    percentage,
  });

  return res.status(201).json({ status: "success", message: "Quiz result saved.", result: savedResult });
};

const getMyResults = (req, res) => {
  const userId = req.user.userId;
  const results = getResultsByUserId(userId).sort((a, b) => new Date(b.date) - new Date(a.date));
  return res.json({ status: "success", results });
};

module.exports = {
  saveQuizResult,
  getMyResults,
};

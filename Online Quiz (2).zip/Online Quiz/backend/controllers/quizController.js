const questionsByTopic = require("../data/questions");

const shuffle = (array) => {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
};

const getSelectedTopic = (topic) => {
  const requested = topic ? topic.toLowerCase() : "maths";
  return questionsByTopic[requested] || questionsByTopic.maths;
};

const getQuestions = (req, res) => {
  const topic = req.query.topic ? req.query.topic.toLowerCase() : "maths";
  const selectedQuestions = getSelectedTopic(topic);
  const shuffledQuestions = shuffle(selectedQuestions);

  const quizQuestions = shuffledQuestions.map(({ id, question, options, timer }) => ({
    id,
    question,
    options,
    timer,
  }));

  res.json({
    status: "success",
    topic,
    totalQuestions: quizQuestions.length,
    questions: quizQuestions,
  });
};

const submitAnswers = (req, res) => {
  const answers = Array.isArray(req.body.answers) ? req.body.answers : [];
  const topic = req.body.topic ? req.body.topic.toLowerCase() : "maths";
  const selectedQuestions = getSelectedTopic(topic);

  let correctAnswers = 0;

  const results = selectedQuestions.map((question) => {
    const userAnswer = answers.find((item) => item.id === question.id)?.answer ?? null;
    const isCorrect = userAnswer === question.correctAnswer;

    if (isCorrect) {
      correctAnswers += 1;
    }

    return {
      id: question.id,
      question: question.question,
      correctAnswer: question.correctAnswer,
      userAnswer,
      isCorrect,
    };
  });

  const totalQuestions = selectedQuestions.length;
  const wrongAnswers = totalQuestions - correctAnswers;
  const percentage = totalQuestions ? Math.round((correctAnswers / totalQuestions) * 100) : 0;

  res.json({
    status: "success",
    score: correctAnswers,
    totalQuestions,
    correctAnswers,
    wrongAnswers,
    percentage,
    results,
  });
};

module.exports = {
  getQuestions,
  submitAnswers,
};

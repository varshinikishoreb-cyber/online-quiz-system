const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { findUserByEmail, createUser, findUserById, updatePassword, updateUsername } = require("../models/userModel");

const JWT_SECRET = process.env.JWT_SECRET || "supersecretkey123";
const JWT_EXPIRES_IN = "3h";
const JWT_RESET_SECRET = process.env.JWT_RESET_SECRET || "resetsecretkey123";
const JWT_RESET_EXPIRES_IN = "15m";

const registerUser = async (req, res) => {
  const { email, password, name } = req.body;

  if (!email || !password) {
    return res.status(400).json({ status: "error", message: "Email and password are required." });
  }

  const existingUser = findUserByEmail(email);
  if (existingUser) {
    return res.status(409).json({ status: "error", message: "A user with this email already exists." });
  }

  const username = name ? name.trim() : email.split("@")[0];
  const passwordHash = await bcrypt.hash(password, 10);
  const newUser = createUser(email, passwordHash, username);
  const token = jwt.sign({ userId: newUser.id, email: newUser.email, username: newUser.username }, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });

  return res.status(201).json({
    status: "success",
    message: "User registered successfully.",
    token,
    user: { id: newUser.id, email: newUser.email, username: newUser.username },
  });
};

const loginUser = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ status: "error", message: "Email and password are required." });
  }

  const user = findUserByEmail(email);
  if (!user) {
    return res.status(401).json({ status: "error", message: "Invalid email or password." });
  }

  const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
  if (!isPasswordValid) {
    return res.status(401).json({ status: "error", message: "Invalid email or password." });
  }

  const token = jwt.sign({ userId: user.id, email: user.email, username: user.username }, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });

  return res.json({
    status: "success",
    message: "Login successful.",
    token,
    user: { id: user.id, email: user.email, username: user.username },
  });
};

const forgotPassword = (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ status: "error", message: "Email is required." });
  }

  const user = findUserByEmail(email);
  if (!user) {
    return res.status(404).json({ status: "error", message: "No account found with that email." });
  }

  const resetToken = jwt.sign({ userId: user.id, email: user.email }, JWT_RESET_SECRET, {
    expiresIn: JWT_RESET_EXPIRES_IN,
  });

  const resetLink = `http://localhost:5000/reset-password?token=${resetToken}`;
  console.log(`Password reset link for ${email}: ${resetLink}`);

  return res.json({
    status: "success",
    message: "Password reset link has been generated. Check the server console for the link.",
    resetLink,
  });
};

const resetPassword = async (req, res) => {
  const { token, password } = req.body;

  if (!token || !password) {
    return res.status(400).json({ status: "error", message: "Reset token and new password are required." });
  }

  try {
    const decoded = jwt.verify(token, JWT_RESET_SECRET);
    const user = findUserById(decoded.userId);

    if (!user || user.email !== decoded.email) {
      return res.status(401).json({ status: "error", message: "Invalid reset token." });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    updatePassword(user.id, passwordHash);

    return res.json({ status: "success", message: "Password has been updated successfully." });
  } catch (error) {
    return res.status(401).json({ status: "error", message: "Reset token is invalid or expired." });
  }
};

const updateProfile = (req, res) => {
  const { name } = req.body;
  const userId = req.user.userId;

  if (!name || !name.trim()) {
    return res.status(400).json({ status: "error", message: "Display name is required." });
  }

  const updatedUser = updateUsername(userId, name.trim());
  if (!updatedUser) {
    return res.status(404).json({ status: "error", message: "User not found." });
  }

  const token = jwt.sign({ userId: updatedUser.id, email: updatedUser.email, username: updatedUser.username }, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });

  return res.json({
    status: "success",
    message: "Profile updated successfully.",
    token,
    user: { id: updatedUser.id, email: updatedUser.email, username: updatedUser.username },
  });
};

module.exports = {
  registerUser,
  loginUser,
  forgotPassword,
  resetPassword,
  updateProfile,
};

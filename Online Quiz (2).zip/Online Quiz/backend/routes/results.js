const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const { saveQuizResult, getMyResults } = require("../controllers/resultsController");

router.post("/quiz/save-result", authMiddleware, saveQuizResult);
router.get("/quiz/my-results", authMiddleware, getMyResults);

module.exports = router;

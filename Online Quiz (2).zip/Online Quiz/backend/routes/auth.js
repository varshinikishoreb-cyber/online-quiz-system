const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const { registerUser, loginUser, forgotPassword, resetPassword, updateProfile } = require("../controllers/authController");

// POST /api/auth/register -> create a new user with hashed password
router.post("/register", registerUser);

// POST /api/auth/login -> validate credentials and return JWT token
router.post("/login", loginUser);

// POST /api/auth/forgot-password -> generate a reset token and log the link
router.post("/forgot-password", forgotPassword);

// POST /api/auth/reset-password -> verify token and update password
router.post("/reset-password", resetPassword);

// PUT /api/auth/profile -> update current user's display name
router.put("/profile", authMiddleware, updateProfile);

module.exports = router;

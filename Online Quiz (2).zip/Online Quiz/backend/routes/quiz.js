const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const { getQuestions, submitAnswers } = require("../controllers/quizController");

// GET /api/questions?topic=maths or /api/questions?topic=webdev
router.get("/questions", authMiddleware, getQuestions);

// POST /api/submit -> evaluate submitted answers and return score
router.post("/submit", authMiddleware, submitAnswers);

module.exports = router;

const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const { getQuestions, submitAnswers } = require("../controllers/quizController");

// GET /api/questions -> return quiz questions for authenticated users
router.get("/questions", authMiddleware, getQuestions);

// POST /api/submit -> evaluate submitted answers and return score for authenticated users
router.post("/submit", authMiddleware, submitAnswers);

module.exports = router;
